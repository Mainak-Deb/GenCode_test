bool isEven(int number)
{
    // check if the 'number' is even
    return ((number % 2) == 0);
}